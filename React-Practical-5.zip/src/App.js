import React from "react";
import UserListContainer from "./container/UserListContainer";
function App() {
  return <UserListContainer />;
}

export default App;
