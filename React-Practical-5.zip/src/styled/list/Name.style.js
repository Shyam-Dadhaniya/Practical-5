import styled from "styled-components";

const NameStyle = styled.div`
  display: flex;
  flex-direction: column;
`;
export default NameStyle;
