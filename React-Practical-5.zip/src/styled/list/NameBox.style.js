import styled from 'styled-components';

const NameBoxStyle = styled.div`
display: flex;
align-items: center;
`
export default NameBoxStyle